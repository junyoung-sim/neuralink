
#include <iostream>
#include <string>
#include "neural_signal_interpreter.hpp"

using namespace std;

int main()
{
	// unless the directory of the dataset has changed, 
	// this main file is already ready to go 

	//string dataset_storage_dir = "D:\\Neural_Signal_Recognition\\Neural_Signal_Recognition\\NeuralSignalDataSet"; // MSFT-VS
	string dataset_storage_dir = "NeuralSignalDataSet/";

	NeuralSignalInterpreter nsi;

	for (int digit = 0; digit <= 9; digit++) {
		for (int wav = 1; wav <= 9; wav++) {
			string dataset = dataset_storage_dir;
			//dataset += "\\Digit " + to_string(digit) + "\\wave";
			dataset += "/Digit " + to_string(digit) + "/wave";
			dataset += to_string(wav) + ".txt";

			// upload the neural signal dataset directory to the processor
			// this will automatically extract data from the brain wave signal .txt
			nsi.upload_dataset(dataset, digit);
			dataset.clear();
		}
	}

	nsi.interpret_dataset(DEFAULT_SEGMENTATION_WINDOW_SIZE); // process the given datasets
	nsi.train_nn_model(1000, 0.01, 10); // train the neural network model with the datasets

	system("pause");
	return 0;
}
