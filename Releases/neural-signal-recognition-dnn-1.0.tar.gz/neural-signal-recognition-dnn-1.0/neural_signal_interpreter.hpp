/*

ALL CLASSES AND DATA STRUCTURES USED FOR
THE NEURAL SIGNAL INTERPRETER MODULE

*/

#ifndef __NEURAL_SIGNAL_INTERPRETER_HPP_
#define __NEURAL_SIGNAL_INTERPRETER_HPP_

#include <iostream>
#include <string>
#include <vector>

#define MINIMUM_SEGMENTATION_WINDOW_SIZE 5
#define DEFAULT_SEGMENTATION_WINDOW_SIZE 10
#define MAXIMUM_SEGMENTATION_WINDOW_SIZE 25

class NeuralSignal {
private:
	int value;
	int index;
public:
	NeuralSignal() { value = 0; index = 0; }
	NeuralSignal(int val, int idx) : value(val), index(idx) {}
	void set_signal_data(int val, int idx);
	void clone(NeuralSignal src);
	int signal_value();
	int signal_index();
};

class NeuralSignalHolder {
private:
	bool validated;
	int digit_number; // indicates which digit the signal represents (this could be something else based on other purposes)
	unsigned int raw_signal_data_length; // the amount of data points included in the raw signal matrix
	std::vector<double> output;
	std::vector<int> raw_signal; // contains all integer values in the signal stream
	std::vector<int> segmented_signal; // contains the segmented values in the signal stream
	double initial_mse, optimized_mse;
public:
	// initialize neural signal holder by pushing in the raw data
	NeuralSignalHolder() {}
	NeuralSignalHolder(std::vector<int> raw_data, int digit) : raw_signal(raw_data),
		raw_signal_data_length(raw_data.size()), digit_number(digit) {}
	unsigned int raw_signal_data_size();
	unsigned int segmented_signal_data_size();
	int digit();

	std::vector<int> raw_signal_data();
	void _segmented_signal(std::vector<int> processed_matrix);
	int segmented_signal_datapoints(unsigned int index);

	void configure_signal_output_matrix(unsigned int output_matrix_size);
	double desired_output(int node);
	void set_initial_mse(double value);
	void set_optimized_mse(double value);
	double init_mse();
	double opt_mse();
};

class NeuralSignalInterpreter : public NeuralSignalHolder {
private:
	std::vector<NeuralSignalHolder> neural_signal_holder;
	unsigned int minimum_signal_length;
	unsigned int segmented_signal_length;
public:
	NeuralSignalInterpreter() {
		minimum_signal_length = 10000; // DO NOT CHANGE THIS VALUE IN ANY CONDITION
	}
	void upload_dataset(std::string dataset_dir, int digit); // uploading the neural signal dataset
	std::vector<int> neural_signal_sampling(std::vector<int> raw_signal, unsigned int segmentation_range);
	void interpret_dataset(unsigned int segmentation_range); // segmentating the neural signal dataset
	void train_nn_model(unsigned int iterations, double learning_rate, unsigned int amount_of_output_nodes); // training the neural network model with the processed dataset
};

#endif
