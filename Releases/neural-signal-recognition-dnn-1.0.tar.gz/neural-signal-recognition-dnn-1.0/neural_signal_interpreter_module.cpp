/*

CONFIGURATES THE BASIC FUNCTIONS (UPLOADING DATA SET, TRANSFERING DATA)
FOR THE NEURAL SIGNAL INTERPRETER.

*/


#include <iostream>
#include <sstream>
#include <fstream>
#include <string>
#include <vector>
#include <thread>
#include <chrono>
#include "neural_signal_interpreter.hpp"

using namespace std;

// ----------------------------------------------------------------------------------------------------------------------------------

void NeuralSignal::set_signal_data(int val, int idx) {
	value = val;
	index = idx;
}

void NeuralSignal::clone(NeuralSignal src) {
	value = src.signal_value();
	index = src.signal_index();
}

int NeuralSignal::signal_value() {
	return value;
}

int NeuralSignal::signal_index() {
	return index;
}

// ----------------------------------------------------------------------------------------------------------------------------------

void NeuralSignalHolder::configure_signal_output_matrix(unsigned int output_matrix_size) {
	if (digit_number >= output_matrix_size) {
		cout << "this dataset's desired output is exceeding the amount of output nodes, stating that it is invalid for DNN operations" << endl;
		validated = false; // this will disable the training signal dataset to pass through the DNN
	}
	else {
		for (unsigned int i = 0; i < output_matrix_size; i++) {
			(i == digit_number) ? output.push_back(1.00) : output.push_back(0.00);
		}
	}

}

void NeuralSignalHolder::_segmented_signal(vector<int> processed_matrix) {
	segmented_signal = processed_matrix;
}

unsigned int NeuralSignalHolder::segmented_signal_data_size() {
	return segmented_signal.size();
}

unsigned int NeuralSignalHolder::raw_signal_data_size() {
	return raw_signal_data_length;
}

int NeuralSignalHolder::digit() {
	return digit_number;
}

double NeuralSignalHolder::init_mse() {
	return initial_mse;
}

double NeuralSignalHolder::opt_mse() {
	return optimized_mse;
}

vector<int> NeuralSignalHolder::raw_signal_data() {
	return raw_signal;
}

int NeuralSignalHolder::segmented_signal_datapoints(unsigned int index) {
	return segmented_signal[index];
}

double NeuralSignalHolder::desired_output(int node) {
	return output[node];
}

void NeuralSignalHolder::set_initial_mse(double value) {
	initial_mse = value;
}

void NeuralSignalHolder::set_optimized_mse(double value) {
	optimized_mse = value;
}

// ----------------------------------------------------------------------------------------------------------------------------------

void NeuralSignalInterpreter::upload_dataset(string dataset_dir, int digit) {
	int n;
	vector<int> signal_stream;
	char comma[1];

	//ILE *file;
	//errno_t err = fopen_s(&file, dataset_dir.c_str(), "r");

	
	FILE *file = fopen(dataset_dir.c_str(), "r");
	

	if (file == NULL) {
		cout << "ERROR: Could not open file (Wrong directory or contains no data)" << endl;
		return;
	}

	// upload the neural signal data to the dataset stack
	// extract all integer values inside the file
	// fscanf(file, "%d %c", &n, comma)
	while (fscanf(file, "%d %c", &n, comma) != EOF) {
		signal_stream.push_back(n);
	}

	neural_signal_holder.push_back(NeuralSignalHolder(signal_stream, digit));
	cout << "Neural Signal Dataset Uploaded... [DIR = " << dataset_dir << "]" << endl;

	// check if currently uploaded dataset has the smallest data length
	// this process is ESSENTIAL for processing the signal data without any segmentation faults
	if (neural_signal_holder[neural_signal_holder.size() - 1].raw_signal_data_size() < minimum_signal_length) {
		minimum_signal_length = neural_signal_holder[neural_signal_holder.size() - 1].raw_signal_data_size();
	}
	else {}
}

// ----------------------------------------------------------------------------------------------------------------------------------
